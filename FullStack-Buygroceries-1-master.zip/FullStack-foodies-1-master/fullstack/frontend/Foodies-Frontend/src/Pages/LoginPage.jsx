import React from 'react'

const LoginPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default LoginPage
